import darkSocieties from "@/assets/dark-societies-v2.jpg";
import developerVerse from "@/assets/developerverse.jpg.asset.json";
import easyLearners from "@/assets/easylearners.jpg.asset.json";
import shadowKing from "@/assets/shadow-king-v2.jpg";
import dharmaUniverse from "@/assets/dharma-universe-v2.jpg";
import ramayan from "@/assets/dharma-ramayan.jpg.asset.json";
import mahabharat from "@/assets/dharma-mahabharat.jpg.asset.json";
import avatar from "@/assets/mr-dark-v2.jpg";

export const identity = { name: "Aditya Bhat", alias: "Mr. Dark", role: "Developer. Writer. Universe Builder.", location: "India", tagline: "I create Verse, some with words and some with codes.", creed: "Greed is the best thing in the Universe. Mine is for knowledge." };
export const contact = { instagram: "https://www.instagram.com/darkdevelopers_", github: "https://github.com/DarKIsBack", discord: "darkdeveloper_", email: "projectdark2026@gmail.com" };
export const media = { dharmaBanner: dharmaUniverse, avatar };

export const worlds = [
  { to: "/academy", icon: "GraduationCap", number: "01", title: "The Academy", eyebrow: "Learning orbit", description: "Science, programming, and the discipline of building.", gold: false },
  { to: "/codeverse", icon: "Code2", number: "02", title: "CodeVerse", eyebrow: "Digital systems", description: "Platforms, tools, and ideas made real through code.", gold: false },
  { to: "/gameverse", icon: "Gamepad2", number: "03", title: "GameVerse", eyebrow: "Interactive frontier", description: "A future realm where code becomes play.", gold: false },
  { to: "/authorverse", icon: "BookOpen", number: "04", title: "AuthorVerse", eyebrow: "Story archive", description: "Fictional worlds born from imagination.", gold: false },
  { to: "/dharma-yuga", icon: "Sun", number: "05", title: "Dharma Yuga", eyebrow: "Eternal saga", description: "A respectful cinematic vision rooted in Sanatan Dharma.", gold: true },
  { to: "/about", icon: "UserRound", number: "06", title: "About Mr. Dark", eyebrow: "Identity", description: "Meet the creator connecting every universe.", gold: false },
  { to: "/contact", icon: "Send", number: "07", title: "Contact", eyebrow: "Open channel", description: "Connect across verified digital coordinates.", gold: false },
] as const;

export const student = [
  ["Name", "Aditya Bhat"], ["Alias", "Mr. Dark"], ["Current status", "Class 11 Science Student"],
  ["Education", "CBSE Class 11"], ["Stream", "Physics • Chemistry • Mathematics"], ["Current goal", "Learning science while building projects."],
];
export const missions = [
  ["Orbit", "Study Physics", "Mechanics, gravitation, and the laws shaping the cosmos."],
  ["FlaskConical", "Study Chemistry", "Atomic structure, bonding, matter, and transformation."],
  ["Sigma", "Study Mathematics", "Analytical thinking, vectors, geometry, and precision."],
  ["Braces", "Learn Programming", "Expanding JavaScript, Python, C++, and system logic."],
  ["Rocket", "Build Projects", "Turning ideas into useful, resilient digital products."],
  ["PenLine", "Write Stories", "Developing characters, worlds, and connected narratives."],
] as const;
export const skills = ["HTML", "CSS", "JavaScript", "Python", "C++", "NodeJS", "UI Design", "Story Writing"];

export const projects = [
  { name: "DeveloperVerse", status: "LIVE", category: "Developer ecosystem", description: "A developer-services and digital development universe built to help creators discover tools and resources.", features: ["Curated developer resources", "Responsive digital experience", "Evolving builder ecosystem"], tech: ["HTML", "CSS", "JavaScript", "GitHub", "Netlify"], live: "https://org-developerverse.netlify.app/", github: contact.github, image: developerVerse.url },
  { name: "EasyLearners", status: "LIVE", category: "Education platform", description: "An educational platform focused on making science and academic concepts easier to explore.", features: ["Structured learning paths", "Focused reading experience", "Student-first navigation"], tech: ["HTML", "CSS", "JavaScript", "Responsive Design"], live: "https://easylearnerss.netlify.app/", github: contact.github, image: easyLearners.url },
  { name: "NewsVerse", status: "BUILDING", category: "Information", description: "A focused home for technology, science, and developer news.", features: ["Topic discovery", "Focused reading", "Organized information"], tech: ["React", "NodeJS", "APIs"], live: undefined, github: contact.github, image: undefined },
  { name: "CurrencyVerse", status: "BUILDING", category: "Utility", description: "A clear interface for global exchange rates and currency comparisons.", features: ["Rate conversion", "Currency comparison", "Data visualization"], tech: ["JavaScript", "REST APIs", "Responsive UI"], live: undefined, github: contact.github, image: undefined },
  { name: "WeatherChecker", status: "UPCOMING", category: "Weather utility", description: "A planned weather experience for forecasts and atmospheric conditions.", features: ["Forecasts", "Location-aware weather", "Condition summaries"], tech: ["TypeScript", "Open APIs", "Responsive UI"], live: undefined, github: undefined, image: undefined },
] as const;
export const tech = ["HTML", "CSS", "JavaScript", "NodeJS", "Python", "C++", "GitHub", "Netlify"];
export const journey = [
  ["2023", "Foundations", "Started with web fundamentals and C++ problem solving."],
  ["2024", "EasyLearners", "Built an educational interface and adopted responsive design and Git workflows."],
  ["2025", "DeveloperVerse", "Released a public hub for developer tools and began shaping the multi-world concept."],
  ["2026", "Dark Universe V2", "Unifying learning, software, stories, heritage, and future interactive work."],
];

export const stories = [
  { title: "Dark Societies", genre: "Cosmic Mystery / Sci-Fi Thriller", status: "Trilogy in progress", progress: "3 core arcs", world: "Dark Societies Continuum", image: darkSocieties, description: "A trilogy of covert orders, forgotten celestial artifacts, and the fragile boundary between civilization and cosmic enigmas.", parts: ["The Discovery", "The Legend", "The Return of the Legend"] },
  { title: "The Shadow King", genre: "Dark Fantasy", status: "Standalone story", progress: "Drafting and lore building", world: "Umbral Sovereign Realm", image: shadowKing, description: "An exiled sovereign confronts the shadows an empire fears, balancing darkness against absolute tyranny." },
  { title: "The Last Meetup", genre: "Diary-style fiction", status: "Standalone story", progress: "Completed draft", world: "Earth and Neo-Horizon", image: undefined, description: "Diary entries capture one final reunion before familiar lives diverge toward an unknown horizon." },
  { title: "Future Stories", genre: "Speculative fiction", status: "Reserved", progress: "In ideation", world: "The Unnamed Multiverse", image: undefined, description: "A space reserved for new fictional sagas as AuthorVerse expands." },
] as const;

export const seasons = [
  { number: "Season I", title: "Ramayan — The Path of Dharma", subtitle: "Maryada, duty, truth, and the triumph of righteousness", image: ramayan.url, description: "A cinematic exploration of duty, devotion, sacrifice, and the restoration of moral order.", aspects: ["Maryada and ideal conduct", "Devotion and selfless service", "Ayodhya to Lanka", "The triumph of truth"] },
  { number: "Season II", title: "Mahabharat — The Great Dharma War", subtitle: "Kurukshetra, the Bhagavad Gita, karma, and destiny", image: mahabharat.url, description: "A cinematic exploration of moral dilemmas, statecraft, human nature, and duty without attachment.", aspects: ["The wisdom of the Gita", "Kurukshetra and cosmic balance", "Kinship, destiny, and honour", "Where there is Dharma, there is victory"] },
] as const;
export const characters = [
  ["Bhagwan Shri Ram", "Maryada Purushottam", "Duty and righteousness"], ["Bhakt Hanuman", "Sankat Mochan", "Devotion, strength, and humility"], ["Yogeshwar Shri Krishna", "Jagadguru", "Wisdom, karma yoga, and guidance"], ["Arjuna", "Dhananjaya", "Focus and the search for truth"], ["Pitamaha Bhishma", "The Great Vow", "Oath, sacrifice, and nobility"],
];
export const yugas = [
  ["Satya Yuga", "The age of truth", "Purity, meditation, and alignment with cosmic law."], ["Treta Yuga", "The age of Shri Ram", "Honour, sacrifice, and righteous kingship."], ["Dvapara Yuga", "The age of Shri Krishna", "Moral complexity, the Bhagavad Gita, and karma."], ["Kali Yuga", "The current age", "A difficult era where remembrance and truth remain guiding lights."],
];
export const interests = ["Programming", "UI Design", "Anime", "Storytelling", "Space", "Books", "Technology", "Worldbuilding"];
