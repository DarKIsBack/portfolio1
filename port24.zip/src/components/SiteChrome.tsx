import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, Code2, GraduationCap, Home, Menu, Send, Sun, UserRound, Gamepad2, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { CosmicBackground } from "@/components/cosmic/CosmicBackground";
import { contact } from "@/lib/site-data";

const nav = [
  ["/", "Home", Home], ["/academy", "Academy", GraduationCap], ["/codeverse", "CodeVerse", Code2], ["/gameverse", "GameVerse", Gamepad2], ["/authorverse", "AuthorVerse", BookOpen], ["/dharma-yuga", "Dharma Yuga", Sun], ["/about", "About", UserRound], ["/contact", "Contact", Send],
] as const;

export function SiteChrome({ children }: { children: React.ReactNode }) {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const [open, setOpen] = useState(false); const [scrolled, setScrolled] = useState(false); const [progress, setProgress] = useState(0);
  useEffect(() => { setOpen(false); scrollTo({ top: 0 }); }, [path]);
  useEffect(() => { const update = () => { setScrolled(scrollY > 16); const max = document.documentElement.scrollHeight - innerHeight; setProgress(max > 0 ? scrollY / max * 100 : 0); }; update(); addEventListener("scroll", update, { passive: true }); return () => removeEventListener("scroll", update); }, []);
  return <div className="site-shell">
    <CosmicBackground />
    <div className="fixed inset-x-0 top-0 z-[70] h-px bg-border/20"><div className="h-full bg-primary shadow-[0_0_12px_var(--color-primary)]" style={{ width: `${progress}%` }} /></div>
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${scrolled || open ? "border-b border-border/60 bg-background/80 py-3 backdrop-blur-2xl" : "bg-transparent py-5"}`}>
      <div className="mx-auto grid max-w-[1440px] grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 sm:px-8">
        <Link to="/" className="group flex min-w-0 items-center gap-3" aria-label="Dark Universe home"><span className="relative grid size-9 shrink-0 place-items-center rounded-full border border-primary/50 bg-primary/10"><span className="size-3 rounded-full bg-background shadow-[0_0_12px_var(--color-primary)]" /></span><span className="truncate font-display text-sm font-bold tracking-[.18em] text-foreground">DARK UNIVERSE</span></Link>
        <nav className="hidden items-center gap-1 xl:flex" aria-label="Main navigation">{nav.map(([to, label]) => <Link key={to} to={to} className={`rounded-md px-3 py-2 text-xs font-medium transition-colors ${path === to ? to === "/dharma-yuga" ? "bg-gold/10 text-gold" : "bg-primary/15 text-foreground" : "text-muted-foreground hover:bg-accent hover:text-foreground"}`}>{label}</Link>)}</nav>
        <Button variant="glass" size="icon" className="xl:hidden" aria-label={open ? "Close navigation" : "Open navigation"} onClick={() => setOpen((value) => !value)}>{open ? <X /> : <Menu />}</Button>
      </div>
      {open && <nav className="mx-5 mt-3 grid grid-cols-2 gap-2 border-t border-border/40 pt-3 sm:mx-8 sm:grid-cols-4 xl:hidden" aria-label="Mobile navigation">{nav.map(([to, label, Icon]) => <Link key={to} to={to} className={`flex min-h-12 items-center gap-2 rounded-md border px-3 text-sm ${path === to ? "border-primary/60 bg-primary/15 text-foreground" : "border-border/50 bg-card/60 text-muted-foreground"}`}><Icon className="size-4" />{label}</Link>)}</nav>}
    </header>
    <main>{children}</main>
    <footer className="relative border-t border-border/40 px-5 pb-28 pt-10 sm:px-8 sm:pb-10"><div className="mx-auto flex max-w-7xl flex-col gap-6 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-display font-semibold tracking-[.18em]">DARK UNIVERSE</p><p className="mt-1 text-sm text-muted-foreground">Created by Mr. Dark · Aditya Bhat</p></div><div className="flex flex-wrap gap-5 text-sm text-muted-foreground"><a href={contact.github} target="_blank" rel="noreferrer" className="hover:text-foreground">GitHub</a><a href={contact.instagram} target="_blank" rel="noreferrer" className="hover:text-foreground">Instagram</a><a href={`mailto:${contact.email}`} className="hover:text-foreground">Email</a></div></div></footer>
    <nav className="fixed inset-x-3 bottom-3 z-40 grid grid-cols-5 rounded-lg border border-border/70 bg-background/85 p-1.5 shadow-2xl backdrop-blur-2xl sm:hidden" aria-label="Quick navigation">{nav.slice(0, 5).map(([to, label, Icon]) => <Link key={to} to={to} aria-label={label} className={`grid min-h-11 place-items-center rounded-md ${path === to ? "bg-primary/20 text-foreground" : "text-muted-foreground"}`}><Icon className="size-[18px]" /></Link>)}</nav>
  </div>;
}
