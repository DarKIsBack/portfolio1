import { useEffect, useRef, useState, type ReactNode } from "react";
export function Reveal({ children, className = "" }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null); const [visible, setVisible] = useState(false);
  useEffect(() => { const node = ref.current; if (!node) return; const observer = new IntersectionObserver(([entry]) => { if (entry?.isIntersecting) { setVisible(true); observer.disconnect(); } }, { threshold: .08 }); observer.observe(node); return () => observer.disconnect(); }, []);
  return <div ref={ref} className={`${visible ? "reveal-visible" : "reveal-hidden"} ${className}`}>{children}</div>;
}
