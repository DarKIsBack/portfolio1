import { useEffect, useRef } from "react";

export function CosmicBackground() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let frame = 0;
    let stars: { x: number; y: number; r: number; a: number; s: number }[] = [];
    const resize = () => {
      const ratio = Math.min(window.devicePixelRatio, 1.5);
      canvas.width = innerWidth * ratio; canvas.height = innerHeight * ratio;
      canvas.style.width = `${innerWidth}px`; canvas.style.height = `${innerHeight}px`;
      ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
      const count = innerWidth < 640 ? 55 : 120;
      stars = Array.from({ length: count }, () => ({ x: Math.random() * innerWidth, y: Math.random() * innerHeight, r: Math.random() * 1.2 + .25, a: Math.random() * .6 + .2, s: Math.random() * .001 + .0004 }));
    };
    const draw = (time = 0) => {
      ctx.clearRect(0, 0, innerWidth, innerHeight);
      for (const star of stars) {
        const alpha = reduced ? star.a : star.a * (.72 + Math.sin(time * star.s + star.x) * .28);
        ctx.beginPath(); ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(224,231,255,${alpha})`; ctx.fill();
      }
      if (!reduced) frame = requestAnimationFrame(draw);
    };
    resize(); draw();
    addEventListener("resize", resize, { passive: true });
    return () => { cancelAnimationFrame(frame); removeEventListener("resize", resize); };
  }, []);
  return <div className="cosmic-backdrop" aria-hidden="true"><canvas ref={ref} /><div className="nebula nebula-one" /><div className="nebula nebula-two" /><div className="cosmic-noise" /></div>;
}
