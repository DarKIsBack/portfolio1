import type { ReactNode } from "react";
import { ArrowDown } from "lucide-react";
export function WorldHeader({ eyebrow, title, subtitle, children, gold = false, image }: { eyebrow: string; title: string; subtitle: string; children?: ReactNode; gold?: boolean; image?: string }) {
  return <header className="world-hero border-b border-border/40 px-5 pb-16 pt-32 sm:px-8 lg:px-12">
    {image && <img src={image} alt="" className="image-vignette absolute inset-0 h-full w-full object-cover opacity-40" />}
    <div className="cosmic-grid absolute inset-0 opacity-35" />
    <div className="relative z-10 mx-auto w-full max-w-7xl">
      <div className={`mb-5 text-xs font-semibold uppercase tracking-[.3em] ${gold ? "text-gold" : "text-primary"}`}>{eyebrow}</div>
      <h1 className={`max-w-5xl font-display text-5xl font-bold leading-[.95] sm:text-7xl lg:text-8xl ${gold ? "gold-glow font-serif text-gold-foreground" : "text-glow"}`}>{title}</h1>
      <p className="mt-6 max-w-2xl text-base leading-7 text-muted-foreground sm:text-lg">{subtitle}</p>
      {children && <div className="mt-8">{children}</div>}
      <ArrowDown className={`mt-12 size-5 ${gold ? "text-gold" : "text-primary"}`} aria-hidden="true" />
    </div>
  </header>;
}
