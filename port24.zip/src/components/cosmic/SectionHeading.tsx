export function SectionHeading({ eyebrow, title, description, gold = false }: { eyebrow: string; title: string; description?: string; gold?: boolean }) {
  return <div className="mb-10 max-w-3xl"><p className={`text-xs font-semibold uppercase tracking-[.28em] ${gold ? "text-gold" : "text-primary"}`}>{eyebrow}</p><h2 className={`mt-3 font-display text-3xl font-bold sm:text-5xl ${gold ? "font-serif text-gold-foreground" : "text-foreground"}`}>{title}</h2>{description && <p className="mt-4 max-w-2xl leading-7 text-muted-foreground">{description}</p>}</div>;
}
