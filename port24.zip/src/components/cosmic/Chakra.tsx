export function Chakra() {
  const spokes = Array.from({ length: 24 }, (_, i) => {
    const a = (i * Math.PI * 2) / 24;
    return <line key={i} x1="100" y1="100" x2={100 + 79 * Math.cos(a)} y2={100 + 79 * Math.sin(a)} stroke="currentColor" strokeWidth="1.6" />;
  });
  return <svg viewBox="0 0 200 200" className="chakra h-full w-full" aria-label="Rotating golden Dharma Chakra"><circle cx="100" cy="100" r="90" fill="none" stroke="currentColor" strokeWidth="3"/><circle cx="100" cy="100" r="80" fill="none" stroke="currentColor" strokeWidth="1"/>{spokes}<circle cx="100" cy="100" r="18" fill="none" stroke="currentColor" strokeWidth="3"/><circle cx="100" cy="100" r="7" fill="currentColor"/></svg>;
}
