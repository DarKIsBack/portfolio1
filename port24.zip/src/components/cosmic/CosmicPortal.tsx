import { useEffect, useRef } from "react";

export function CosmicPortal() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el || matchMedia("(pointer: coarse)").matches) return;
    const move = (event: PointerEvent) => {
      const rect = el.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width - .5) * 10;
      const y = ((event.clientY - rect.top) / rect.height - .5) * 10;
      el.style.setProperty("--portal-x", `${x}px`); el.style.setProperty("--portal-y", `${y}px`);
    };
    el.addEventListener("pointermove", move);
    return () => el.removeEventListener("pointermove", move);
  }, []);
  return <div ref={ref} className="portal-stage" aria-label="Animated cosmic portal">
    <div className="portal-orbit portal-orbit-one"><i /><i /><i /></div>
    <div className="portal-orbit portal-orbit-two"><i /><i /></div>
    <div className="portal-disc" />
    <div className="portal-lens" />
    <div className="portal-core"><span /></div>
  </div>;
}
