import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowDown, ArrowRight, BookOpen, Code2, Gamepad2, GraduationCap, Send, Sun, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CosmicPortal } from "@/components/cosmic/CosmicPortal";
import { Reveal } from "@/components/cosmic/Reveal";
import { identity, worlds } from "@/lib/site-data";

const icons = { GraduationCap, Code2, Gamepad2, BookOpen, Sun, UserRound, Send };
export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Dark Universe — The Worlds of Mr. Dark" }, { name: "description", content: "Enter the cinematic digital universe of Aditya Bhat: code, stories, learning, games, and Dharma Yuga." },
    { property: "og:title", content: "Dark Universe — The Worlds of Mr. Dark" }, { property: "og:description", content: "Choose a world built with code, stories, learning, and imagination." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }), component: HomePage,
});
function HomePage() { return <>
  <section className="relative mx-auto grid min-h-[94svh] max-w-[1440px] items-center gap-8 overflow-hidden px-5 pb-12 pt-28 sm:px-8 lg:grid-cols-[1.02fr_.98fr] lg:px-12">
    <div className="relative z-10 max-w-2xl">
      <p className="mb-5 text-xs font-semibold uppercase tracking-[.32em] text-primary">Hello, I&apos;m</p>
      <h1 className="text-glow font-display text-6xl font-bold leading-[.86] sm:text-8xl lg:text-[7.8rem]">MR.<br/><span className="text-primary">DARK</span></h1>
      <blockquote className="mt-7 max-w-xl border-l border-primary/60 pl-5 text-lg leading-8 text-foreground/90">“{identity.tagline}”</blockquote>
      <p className="mt-6 text-xl font-medium">{identity.role}</p>
      <p className="mt-2 max-w-xl leading-7 text-muted-foreground">Building digital experiences, projects, and fictional universes from India.</p>
      <div className="mt-8 flex flex-wrap gap-3"><Button asChild variant="cosmic" size="lg"><a href="#worlds">Enter Universe <ArrowDown /></a></Button><Button asChild variant="glass" size="lg"><Link to="/codeverse">Explore CodeVerse <ArrowRight /></Link></Button></div>
    </div>
    <div className="relative flex items-center justify-center"><CosmicPortal /><div className="absolute bottom-[9%] left-1/2 -translate-x-1/2 text-center text-[10px] uppercase tracking-[.32em] text-muted-foreground">Portal 00 · Gateway</div></div>
    <a href="#worlds" className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-[10px] uppercase tracking-[.3em] text-muted-foreground sm:flex">Enter the universe <ArrowDown className="size-4 animate-bounce" /></a>
  </section>
  <section id="worlds" className="relative px-5 py-24 sm:px-8 lg:px-12"><div className="mx-auto max-w-7xl"><Reveal><div className="mb-12 max-w-2xl"><p className="text-xs font-semibold uppercase tracking-[.3em] text-primary">Choose your destination</p><h2 className="mt-4 font-display text-4xl font-bold sm:text-6xl">Seven worlds. One creator.</h2><p className="mt-4 leading-7 text-muted-foreground">Every portal reveals a different dimension of learning, building, play, storytelling, heritage, and identity.</p></div></Reveal>
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-12">{worlds.map((world, index) => { const Icon = icons[world.icon]; return <Reveal key={world.to} className={index < 2 ? "lg:col-span-6" : index === 4 ? "lg:col-span-4" : "lg:col-span-4"}><Link to={world.to} className={`orbital-card glass group relative flex min-h-64 flex-col justify-between overflow-hidden rounded-lg p-6 ${world.gold ? "dharma-surface" : ""}`}><div className="absolute -right-8 -top-8 size-40 rounded-full border border-current opacity-10 transition-transform duration-700 group-hover:scale-125"/><div className="flex items-start justify-between"><span className={`grid size-12 place-items-center rounded-md border ${world.gold ? "border-gold/40 bg-gold/10 text-gold" : "border-primary/40 bg-primary/10 text-primary"}`}><Icon className="size-5" /></span><span className="font-display text-xs tracking-[.24em] text-muted-foreground">{world.number}</span></div><div><p className={`text-xs uppercase tracking-[.24em] ${world.gold ? "text-gold" : "text-primary"}`}>{world.eyebrow}</p><h3 className="mt-2 font-display text-2xl font-semibold">{world.title}</h3><p className="mt-3 max-w-sm text-sm leading-6 text-muted-foreground">{world.description}</p><span className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-foreground">Enter world <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" /></span></div></Link></Reveal>; })}</div>
  </div></section>
</>; }
