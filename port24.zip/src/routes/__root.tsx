import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { HeadContent, Link, Outlet, Scripts, createRootRouteWithContext } from "@tanstack/react-router";
import type { ReactNode } from "react";
import appCss from "../styles.css?url";
import { SiteChrome } from "@/components/SiteChrome";

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" }, { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Dark Universe — Mr. Dark" }, { name: "description", content: "The personal digital universe of developer and writer Aditya Bhat." },
      { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }, { name: "theme-color", content: "#050510" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" }, { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Outfit:wght@300;400;500;600&family=Space+Grotesk:wght@400;500;600;700&display=swap" },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: () => <div className="grid min-h-screen place-items-center px-5 text-center"><div><p className="text-xs uppercase tracking-[.3em] text-primary">Signal lost</p><h1 className="mt-4 font-display text-7xl font-bold">404</h1><p className="mt-3 text-muted-foreground">This coordinate does not exist in Dark Universe.</p><Link to="/" className="mt-8 inline-block text-primary">Return to the gateway</Link></div></div>,
});
function RootShell({ children }: { children: ReactNode }) { return <html lang="en"><head><HeadContent /></head><body>{children}<Scripts /></body></html>; }
function RootComponent() { const { queryClient } = Route.useRouteContext(); return <QueryClientProvider client={queryClient}><SiteChrome><Outlet /></SiteChrome></QueryClientProvider>; }
