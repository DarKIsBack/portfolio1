# Complete Dark Universe V2

## Goal
Finish the supplied semi-built portfolio as a cinematic, responsive seven-world experience for Mr. Dark, preserving verified content and excluding every terminal, shell, executor, console, and chatbot pattern.

## Implementation
- Integrate the supplied shared navigation, cosmic backdrop, scroll progress, footer, portal, reveal effects, and semantic dark-space design system.
- Complete the gateway at `/` with the split introduction, interactive portal, calls to action, and seven world cards.
- Complete dedicated pages for The Academy, CodeVerse, GameVerse, AuthorVerse, Dharma Yuga, About, and Contact.
- Reuse the supplied artwork and verified links for DeveloperVerse, EasyLearners, GitHub, Instagram, Discord, and email; unavailable destinations remain disabled.
- Preserve real education, project, story, and identity details without adding statistics, clients, achievements, or other unsupported claims.

## Experience and quality
- Refine desktop, laptop, tablet, and 360px mobile layouts, including touch navigation and reduced particle density.
- Keep motion subtle and efficient with transform-based effects, reduced-motion support, lazy-loaded artwork, and no horizontal overflow.
- Ensure every page has unique search and sharing metadata, keyboard-friendly controls, readable contrast, and descriptive imagery.
- Validate all routes, external links, copy actions, desktop and mobile presentation, console output, and runtime behavior.

## Technical approach
- Keep the existing TanStack Start structure with one route per world and centralized content for future expansion.
- Use the existing lightweight canvas star field and CSS portal rather than adding heavy 3D dependencies.
- Reconcile supplied source files with the current project carefully, excluding archive metadata and obsolete template content.
